<?php

namespace CoreInterfaces\Core\Authentication;

interface AuthGroup
{
    public const AND = "And";
    public const OR = "Or";
}
