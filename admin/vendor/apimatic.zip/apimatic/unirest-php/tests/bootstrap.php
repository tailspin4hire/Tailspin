<?php

require_once dirname(__FILE__) . '/../src/Configuration.php';
require_once dirname(__FILE__) . '/../src/HttpClient.php';
require_once dirname(__FILE__) . '/../src/Response.php';
require_once dirname(__FILE__) . '/../src/Request/Body.php';
require_once dirname(__FILE__) . '/../src/Request/Request.php';
require_once dirname(__FILE__) . '/../tests/Mocking/HttpClientChild.php';
