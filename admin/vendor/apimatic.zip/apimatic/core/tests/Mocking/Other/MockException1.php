<?php

namespace Core\Tests\Mocking\Other;

class MockException1 extends MockException
{
    /**
     * @var MockClass
     */
    public $other1;
}
